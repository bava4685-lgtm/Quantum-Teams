# Xexnaro Daily Poster Generator (v2)

Flask + Pillow generator for 1080 x 1080 Xexnaro social posters, built in the
same format as the "SEO Tip of the Day" reference poster:
logo header, tag pill, two-tone headline, short intro, script accent,
four icon cards, wave footer with website and tagline.

## What changed
- **10 new templates** - same layout family, different palette, background decor,
  photo shape, card style, footer wave and script accent.
- **No stock photo of a person.** Each poster shows a drawn laptop whose screen changes per post (website, analytics, social feed, search results, brand kit, strategy, shop, contact) and carries the Xexnaro logo. Set it with `"hero"` in the knowledge base (website, chart, social, search, brand, strategy, shop, mail).
- **Xexnaro logo on every poster** (`assets/logo/xexnaro_logo.jpg`). Generation stops with an error if the logo is missing.
- **Content comes from `content/xexnaro_knowledge_base.json`** - company profile plus 10 fresh Xexnaro posts (4 cards each).
  The old `daily_content.json` is no longer used.
- No date, price or phone number is ever printed (the generator rejects posts containing them).

## Run
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python daily.py --all-templates     # 10-day series -> output/templates/
python daily.py                     # today's poster -> output/daily/
python daily.py --days 10           # next 10 days
python daily.py --template 4        # force a template
python app.py                       # http://127.0.0.1:5000/generate , /daily , /templates
```

## Adding more content
Add entries to `posts` in `content/xexnaro_knowledge_base.json`:
`tag`, `headline` (2 lines), `sub`, `script` (2 words), `hero`, `points` (exactly 4 x `icon`, `title`, `desc`).
Icons: search, doc, gauge, phone, chart, target, shield, chat, palette, link, cart, bulb, star, play, code, globe, pin, people, megaphone, mail, lock, calendar.
Keep titles short (2 lines max) and descriptions under about 45 characters.

## Assets
```text
assets/logo/xexnaro_logo.jpg
assets/fonts/Poppins-*.ttf
```
