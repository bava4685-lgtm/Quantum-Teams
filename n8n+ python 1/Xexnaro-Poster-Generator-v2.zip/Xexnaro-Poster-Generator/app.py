from flask import Flask, request, send_file, jsonify
import os, traceback
from datetime import date, datetime
import daily

app=Flask(__name__)
BASE_DIR=os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR=os.path.join(BASE_DIR,'output','daily')
os.makedirs(OUTPUT_DIR,exist_ok=True)

@app.get('/')
def home():
    return jsonify({
        'success':True,
        'service':'Xexnaro Daily Poster Generator v2',
        'website':'https://xexnaro.in/',
        'language':'English only',
        'date_on_poster':False,
        'logo_on_every_poster':True,
        'templates':10,'content_source':'content/xexnaro_knowledge_base.json',
        'usage':{
            'daily':'/daily',
            'daily_template':'/daily?template=1',
            'generate':'/generate',
            'generate_template':'/generate?template=1',
            'all_templates':'/templates'
        }
    })

@app.get('/daily')
def daily_poster():
    try:
        d=request.args.get('date')
        day=datetime.strptime(d,'%Y-%m-%d').date() if d else date.today()
        template=request.args.get('template')
        template=int(template) if template else None
        path,entry,t=daily.generate(day,template)
        return send_file(path,mimetype='image/png',as_attachment=False)
    except Exception as exc:
        traceback.print_exc(); return jsonify({'success':False,'error':str(exc)}),500

@app.route('/generate',methods=['GET','POST'])
def generate():
    try:
        if request.method=='POST':
            data=request.get_json(silent=True) or {}
            template=data.get('template')
        else:
            template=request.args.get('template')
        template=int(template) if template else None
        path,entry,t=daily.generate(date.today(),template)
        return send_file(path,mimetype='image/png',as_attachment=False)
    except Exception as exc:
        traceback.print_exc(); return jsonify({'success':False,'error':str(exc)}),500

@app.get('/templates')
def templates():
    try:
        paths=daily.generate_ten()
        return jsonify({'success':True,'count':len(paths),'files':[os.path.relpath(p,BASE_DIR).replace('\\','/') for p in paths]})
    except Exception as exc:
        traceback.print_exc(); return jsonify({'success':False,'error':str(exc)}),500

if __name__=='__main__':
    print('='*72)
    print('XEXNARO DAILY ENGLISH KNOWLEDGE POSTER GENERATOR')
    print('='*72)
    print('Server: http://127.0.0.1:5000')
    print('Generate:')
    print('http://127.0.0.1:5000/generate')
    print('http://127.0.0.1:5000/generate?template=1')
    print('Daily:')
    print('http://127.0.0.1:5000/daily')
    print('Templates:')
    print('http://127.0.0.1:5000/templates')
    print('='*72)
    app.run(host='127.0.0.1',port=5000,debug=False)
