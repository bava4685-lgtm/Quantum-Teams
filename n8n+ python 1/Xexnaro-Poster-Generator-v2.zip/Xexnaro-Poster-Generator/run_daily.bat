@echo off
cd /d "%~dp0"
python daily.py --all-templates
python daily.py
pause
