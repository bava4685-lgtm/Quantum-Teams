"""Xexnaro daily knowledge poster generator (v2 - reference-style templates).

- 1080x1080 social posters rendered at 2x and downsampled for smooth edges.
- Same layout family as the reference "SEO Tip of the Day" poster:
  logo header, tag pill, two-tone headline, short intro, script accent,
  four icon cards, wave footer with website + tagline.
- 10 distinct templates (palette, background decor, photo shape, card style,
  footer wave) - each day uses a different template AND a different post.
- Content comes from content/xexnaro_knowledge_base.json (Xexnaro only).
- The Xexnaro logo is placed on every poster; generation fails if it is missing.
- No dates, prices or phone numbers are ever printed.
"""
import argparse, json, math, os, re
from datetime import date, datetime, timedelta
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageOps

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.path.join(BASE_DIR, 'assets', 'fonts')
LOGO_PATH = os.path.join(BASE_DIR, 'assets', 'logo', 'xexnaro_logo.jpg')
PHOTO_PATH = os.path.join(BASE_DIR, 'assets', 'photo_person_laptop.jpg')
KB_PATH = os.path.join(BASE_DIR, 'content', 'xexnaro_knowledge_base.json')
OUTPUT_DIR = os.path.join(BASE_DIR, 'output', 'daily')
TEMPLATE_DIR = os.path.join(BASE_DIR, 'output', 'templates')
W = H = 1080
SS = 2  # supersampling factor


def S(v):
    return int(round(v * SS))


# --------------------------------------------------------------------------
# Themes: 10 templates, same layout family, different look
# --------------------------------------------------------------------------
def T(name, bg, ink, muted, accent, hl2, accent2, foot, dark, card, photo, deco, wave, script):
    return dict(name=name, bg=bg, ink=ink, muted=muted, accent=accent, hl2=hl2, accent2=accent2,
                foot=foot, dark=dark, card=card, photo=photo, deco=deco, wave=wave, script=script)


THEMES = [
    T('royal-violet', ((255, 255, 255), (243, 238, 255)), (14, 10, 60), (76, 70, 112), (98, 24, 232), (98, 24, 232), (139, 70, 255),
      ((44, 14, 150), (98, 30, 232)), False, 'white', 'fade', 'diamond', 'wave', (98, 24, 232)),
    T('indigo-night', ((14, 10, 52), (40, 18, 108)), (255, 255, 255), (208, 200, 244), (139, 92, 246), (196, 170, 255), (167, 139, 250),
      ((76, 29, 149), (124, 58, 237)), True, 'glass', 'round', 'hex', 'double', (196, 170, 255)),
    T('orchid', ((255, 251, 255), (250, 234, 255)), (46, 8, 60), (100, 70, 112), (162, 28, 175), (162, 28, 175), (217, 70, 239),
      ((100, 20, 112), (192, 38, 211)), False, 'topbar', 'circle', 'dots', 'arc', (162, 28, 175)),
    T('ocean-blue', ((247, 250, 255), (222, 235, 255)), (12, 24, 70), (70, 84, 128), (37, 70, 235), (37, 70, 235), (99, 102, 241),
      ((30, 41, 160), (59, 110, 246)), False, 'outline', 'arch', 'rings', 'slant', (37, 70, 235)),
    T('teal-spark', ((246, 255, 252), (228, 244, 255)), (20, 14, 66), (74, 80, 112), (91, 33, 200), (91, 33, 200), (20, 184, 166),
      ((59, 22, 140), (16, 140, 160)), False, 'leftbar', 'hex', 'stripes', 'wave', (13, 148, 136)),
    T('sunset-glow', ((255, 252, 249), (255, 236, 242)), (40, 14, 60), (104, 78, 112), (124, 45, 220), (124, 45, 220), (244, 96, 96),
      ((88, 28, 170), (232, 92, 112)), False, 'white', 'diag', 'blobs', 'double', (232, 80, 90)),
    T('deep-purple', ((30, 10, 84), (72, 20, 156)), (255, 255, 255), (222, 212, 252), (168, 120, 255), (222, 196, 255), (192, 150, 255),
      ((18, 6, 64), (58, 18, 140)), True, 'white', 'circle', 'rings', 'arc', (222, 196, 255)),
    T('lavender-soft', ((245, 241, 255), (228, 218, 255)), (30, 12, 80), (82, 70, 124), (126, 34, 206), (126, 34, 206), (168, 85, 247),
      ((72, 24, 150), (140, 60, 235)), False, 'topbar', 'fade', 'dots', 'slant', (126, 34, 206)),
    T('emerald-edge', ((247, 255, 251), (234, 247, 255)), (18, 18, 64), (72, 84, 112), (79, 70, 229), (79, 70, 229), (16, 185, 129),
      ((49, 46, 129), (14, 150, 112)), False, 'outline', 'round', 'diamond', 'wave', (5, 150, 105)),
    T('golden-violet', ((255, 253, 247), (255, 244, 226)), (36, 14, 70), (100, 84, 112), (109, 40, 217), (109, 40, 217), (245, 158, 11),
      ((58, 18, 140), (132, 62, 232)), False, 'leftbar', 'arch', 'hex', 'double', (217, 119, 6)),
]

# --------------------------------------------------------------------------
# Basic helpers
# --------------------------------------------------------------------------
_fc = {}


def font(weight, size):
    fn = {'regular': 'Poppins-Regular.ttf', 'medium': 'Poppins-Medium.ttf', 'bold': 'Poppins-Bold.ttf'}[weight]
    k = (fn, size)
    if k not in _fc:
        try:
            _fc[k] = ImageFont.truetype(os.path.join(FONT_DIR, fn), S(size))
        except OSError:
            fb = 'DejaVuSans-Bold.ttf' if weight == 'bold' else 'DejaVuSans.ttf'
            _fc[k] = ImageFont.truetype(os.path.join(FONT_DIR, fb), S(size))
    return _fc[k]


_measure = ImageDraw.Draw(Image.new('RGB', (4, 4)))


def tw(s, f):
    return _measure.textlength(s, font=f) / SS


def wrap(text, f, maxw):
    out, cur = [], ''
    for word in str(text).split():
        trial = (cur + ' ' + word).strip()
        if not cur or tw(trial, f) <= maxw:
            cur = trial
        else:
            out.append(cur)
            cur = word
    if cur:
        out.append(cur)
    return out


def fit(text, maxw, start, minimum, weight='bold'):
    s = start
    while s > minimum and tw(text, font(weight, s)) > maxw:
        s -= 2
    return font(weight, s), s


def txt(d, x, y, s, f, fill, anchor='la'):
    d.text((S(x), S(y)), s, font=f, fill=fill, anchor=anchor)


def spaced(d, x, y, s, f, fill, gap):
    for ch in s:
        txt(d, x, y, ch, f, fill)
        x += tw(ch, f) + gap


def mix(a, b, t):
    return tuple(int(a[i] * (1 - t) + b[i] * t) for i in range(3))


def vgrad(size, top, bot):
    m = Image.linear_gradient('L').resize(size)
    return Image.composite(Image.new('RGB', size, bot), Image.new('RGB', size, top), m).convert('RGBA')


def hgrad(size, left, right):
    m = Image.linear_gradient('L').rotate(90).resize(size)
    return Image.composite(Image.new('RGB', size, right), Image.new('RGB', size, left), m).convert('RGBA')


def layer(img):
    return Image.new('RGBA', img.size, (0, 0, 0, 0))


def shadow(img, box, radius, off=(0, 10), blur=16, color=(40, 20, 110, 60)):
    sh = layer(img)
    sd = ImageDraw.Draw(sh)
    x1, y1, x2, y2 = box
    sd.rounded_rectangle((S(x1 + off[0]), S(y1 + off[1]), S(x2 + off[0]), S(y2 + off[1])), radius=S(radius), fill=color)
    img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(S(blur))))


def hexpoly(cx, cy, r, rot=0):
    return [(S(cx + r * math.cos(math.radians(60 * k + 30 + rot))), S(cy + r * math.sin(math.radians(60 * k + 30 + rot)))) for k in range(6)]


# --------------------------------------------------------------------------
# Icons (line icons drawn from primitives)
# --------------------------------------------------------------------------
def icon(d, name, cx, cy, r, col, sw=3.0):
    w = max(2, S(sw))

    def P(x, y):
        return (S(cx + x * r), S(cy + y * r))

    def dot(p):
        d.ellipse((p[0] - w / 2, p[1] - w / 2, p[0] + w / 2, p[1] + w / 2), fill=col)

    def line(pts):
        q = [P(*p) for p in pts]
        d.line(q, fill=col, width=w, joint='curve')
        dot(q[0]); dot(q[-1])

    def circ(x, y, rad, fill=False):
        box = (S(cx + (x - rad) * r), S(cy + (y - rad) * r), S(cx + (x + rad) * r), S(cy + (y + rad) * r))
        if fill:
            d.ellipse(box, fill=col)
        else:
            d.ellipse(box, outline=col, width=w)

    def rr(x1, y1, x2, y2, rad):
        d.rounded_rectangle((P(x1, y1), P(x2, y2)), radius=S(rad * r), outline=col, width=w)

    def arc(x, y, rad, a0, a1):
        d.arc((S(cx + (x - rad) * r), S(cy + (y - rad) * r), S(cx + (x + rad) * r), S(cy + (y + rad) * r)), a0, a1, fill=col, width=w)

    if name == 'search':
        circ(-0.15, -0.15, 0.55); line([(0.25, 0.25), (0.78, 0.78)])
    elif name == 'doc':
        rr(-0.5, -0.78, 0.5, 0.78, 0.12); line([(-0.25, -0.35), (0.25, -0.35)]); line([(-0.25, 0.0), (0.25, 0.0)]); line([(-0.25, 0.35), (0.05, 0.35)])
    elif name == 'gauge':
        arc(0, 0.3, 0.82, 180, 360); line([(0, 0.3), (0.42, -0.15)]); circ(0, 0.3, 0.1, True)
        line([(-0.82, 0.3), (-0.66, 0.3)]); line([(0.66, 0.3), (0.82, 0.3)])
    elif name == 'phone':
        rr(-0.4, -0.8, 0.4, 0.8, 0.15); line([(-0.13, 0.55), (0.13, 0.55)])
    elif name == 'chart':
        line([(-0.8, -0.7), (-0.8, 0.7), (0.8, 0.7)]); line([(-0.4, 0.7), (-0.4, 0.15)]); line([(0, 0.7), (0, -0.15)]); line([(0.4, 0.7), (0.4, -0.5)])
    elif name == 'target':
        circ(0, 0, 0.8); circ(0, 0, 0.45); circ(0, 0, 0.12, True)
    elif name == 'shield':
        line([(0, -0.8), (0.62, -0.52), (0.56, 0.18), (0, 0.82), (-0.56, 0.18), (-0.62, -0.52), (0, -0.8)]); line([(-0.25, 0.0), (-0.05, 0.22), (0.3, -0.18)])
    elif name == 'chat':
        rr(-0.82, -0.62, 0.82, 0.3, 0.26); line([(-0.3, 0.3), (-0.45, 0.78), (0.05, 0.3)])
        for x in (-0.35, 0, 0.35):
            circ(x, -0.16, 0.06, True)
    elif name == 'palette':
        circ(0, 0, 0.82)
        for x, y in ((-0.3, -0.28), (0.12, -0.42), (0.42, -0.04), (-0.38, 0.2)):
            circ(x, y, 0.09, True)
    elif name == 'link':
        rr(-0.88, -0.3, 0.15, 0.3, 0.3); rr(-0.15, -0.3, 0.88, 0.3, 0.3)
    elif name == 'cart':
        line([(-0.85, -0.6), (-0.5, -0.6), (-0.2, 0.25), (0.55, 0.25), (0.7, -0.3), (-0.4, -0.3)]); circ(-0.1, 0.6, 0.1, True); circ(0.45, 0.6, 0.1, True)
    elif name == 'bulb':
        circ(0, -0.2, 0.52); line([(-0.2, 0.45), (0.2, 0.45)]); line([(-0.14, 0.7), (0.14, 0.7)])
    elif name == 'star':
        pts = []
        for k in range(11):
            rad = 0.88 if k % 2 == 0 else 0.4
            a = math.radians(-90 + 36 * k)
            pts.append((rad * math.cos(a), rad * math.sin(a)))
        line(pts)
    elif name == 'play':
        rr(-0.82, -0.58, 0.82, 0.58, 0.2); d.polygon([P(-0.15, -0.26), P(0.28, 0), P(-0.15, 0.26)], fill=col)
    elif name == 'code':
        line([(-0.35, -0.45), (-0.82, 0), (-0.35, 0.45)]); line([(0.35, -0.45), (0.82, 0), (0.35, 0.45)]); line([(0.12, -0.62), (-0.12, 0.62)])
    elif name == 'globe':
        circ(0, 0, 0.82); line([(-0.82, 0), (0.82, 0)])
        d.ellipse((P(-0.36, -0.82), P(0.36, 0.82)), outline=col, width=w); line([(-0.68, -0.42), (0.68, -0.42)]); line([(-0.68, 0.42), (0.68, 0.42)])
    elif name == 'pin':
        circ(0, -0.25, 0.5); line([(-0.42, 0.0), (0, 0.82), (0.42, 0.0)]); circ(0, -0.25, 0.14, True)
    elif name == 'people':
        circ(0, -0.4, 0.27); arc(0, 0.62, 0.55, 180, 360)
        circ(-0.68, -0.22, 0.18); circ(0.68, -0.22, 0.18); arc(-0.68, 0.5, 0.36, 180, 360); arc(0.68, 0.5, 0.36, 180, 360)
    elif name == 'megaphone':
        line([(-0.78, -0.2), (-0.78, 0.2), (-0.3, 0.2), (0.62, 0.66), (0.62, -0.66), (-0.3, -0.2), (-0.78, -0.2)]); line([(-0.52, 0.2), (-0.4, 0.72), (-0.12, 0.72)])
    elif name == 'mail':
        rr(-0.82, -0.58, 0.82, 0.58, 0.1); line([(-0.8, -0.5), (0, 0.12), (0.8, -0.5)])
    elif name == 'lock':
        rr(-0.55, -0.1, 0.55, 0.78, 0.12); arc(0, -0.1, 0.36, 180, 360); circ(0, 0.3, 0.08, True)
    elif name == 'calendar':
        rr(-0.78, -0.6, 0.78, 0.78, 0.12); line([(-0.78, -0.18), (0.78, -0.18)]); line([(-0.36, -0.85), (-0.36, -0.45)]); line([(0.36, -0.85), (0.36, -0.45)])
        for x, y in ((-0.35, 0.18), (0.0, 0.18), (0.35, 0.18), (-0.35, 0.5), (0.0, 0.5)):
            circ(x, y, 0.06, True)
    else:
        circ(0, 0, 0.7)


# --------------------------------------------------------------------------
# Building blocks
# --------------------------------------------------------------------------
def deco(img, th):
    ov = layer(img)
    d = ImageDraw.Draw(ov, 'RGBA')
    a1, a2 = th['accent'], th['accent2']
    kind = th['deco']
    if kind == 'diamond':
        for pts, c, al in (([(-70, 330), (70, 190), (210, 330), (70, 470)], a1, 34), ([(-30, 560), (40, 490), (110, 560), (40, 630)], a2, 26),
                           ([(960, 470), (1030, 400), (1100, 470), (1030, 540)], a2, 30)):
            d.polygon([(S(x), S(y)) for x, y in pts], fill=c + (al,))
    elif kind == 'dots':
        for gx in range(8):
            for gy in range(6):
                d.ellipse((S(880 + gx * 22), S(500 + gy * 22), S(886 + gx * 22), S(506 + gy * 22)), fill=a1 + (70,))
        for gx in range(5):
            for gy in range(5):
                d.ellipse((S(24 + gx * 22), S(160 + gy * 22), S(30 + gx * 22), S(166 + gy * 22)), fill=a2 + (60,))
    elif kind == 'hex':
        for cx, cy, r, al in ((990, 560, 62, 60), (905, 620, 40, 50), (50, 470, 54, 50), (330, 150, 30, 40)):
            d.polygon(hexpoly(cx, cy, r), outline=(a2 if not th['dark'] else (200, 180, 255)) + (al,), width=S(3))
    elif kind == 'rings':
        for rad, al in ((230, 60), (290, 44), (350, 30)):
            d.ellipse((S(860 - rad), S(250 - rad), S(860 + rad), S(250 + rad)), outline=a1 + (al,), width=S(3))
    elif kind == 'stripes':
        for k in range(9):
            d.line((S(620 + k * 40), 0, S(300 + k * 40), S(320)), fill=a2 + (30,), width=S(12))
    elif kind == 'blobs':
        d.ellipse((S(700), S(-100), S(1150), S(330)), fill=a2 + (70,))
        d.ellipse((S(-120), S(380), S(200), S(700)), fill=a1 + (40,))
        ov = ov.filter(ImageFilter.GaussianBlur(S(40)))
    img.alpha_composite(ov)



def _logo_badge(px):
    lg = ImageOps.fit(Image.open(LOGO_PATH).convert('RGB'), (px, px), Image.LANCZOS).convert('RGBA')
    m = Image.new('L', lg.size, 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, px - 1, px - 1), radius=int(px * 0.26), fill=255)
    lg.putalpha(m)
    return lg


def hero_image(w, h, th, entry):
    """Drawn laptop hero (replaces the stock photo). Screen content depends on entry['hero']."""
    if not os.path.exists(LOGO_PATH):
        raise FileNotFoundError('Xexnaro logo missing: ' + LOGO_PATH)
    kind = entry.get('hero', 'website')
    a1, a2, dark = th['accent'], th['accent2'], th['dark']
    W_, H_ = S(w), S(h)
    if dark:
        bg = vgrad((W_, H_), mix(a1, (20, 8, 70), 0.55), mix(a2, (20, 8, 70), 0.35))
    else:
        bg = vgrad((W_, H_), mix(a2, (255, 255, 255), 0.78), mix(a1, (255, 255, 255), 0.5))
    d = ImageDraw.Draw(bg, 'RGBA')
    # soft glow + floor shadow
    gl = Image.new('RGBA', bg.size, (0, 0, 0, 0))
    ImageDraw.Draw(gl).ellipse((S(w * 0.1), S(h * 0.08), S(w * 0.9), S(h * 0.8)), fill=(255, 255, 255, 90))
    bg.alpha_composite(gl.filter(ImageFilter.GaussianBlur(S(30))))
    d = ImageDraw.Draw(bg, 'RGBA')
    sw = w * {'fade': 0.74, 'round': 0.92, 'circle': 0.84, 'arch': 0.9, 'hex': 0.86, 'diag': 0.84}[th['photo']]
    sh = sw * 0.60
    cx = w / 2 + (w * 0.08 if th['photo'] == 'fade' else 0)
    top = (h - (sh + 24)) / 2 - 8
    x1, x2 = cx - sw / 2, cx + sw / 2
    sd = Image.new('RGBA', bg.size, (0, 0, 0, 0))
    ImageDraw.Draw(sd).ellipse((S(x1 - 20), S(top + sh + 10), S(x2 + 20), S(top + sh + 44)), fill=(20, 8, 70, 110))
    bg.alpha_composite(sd.filter(ImageFilter.GaussianBlur(S(10))))
    d = ImageDraw.Draw(bg, 'RGBA')
    # base then screen
    d.rounded_rectangle((S(x1 - 26), S(top + sh), S(x2 + 26), S(top + sh + 20)), radius=S(10), fill=(214, 210, 232, 255))
    d.rectangle((S(x1 - 26), S(top + sh), S(x2 + 26), S(top + sh + 8)), fill=(226, 222, 242, 255))
    d.rounded_rectangle((S(cx - 40), S(top + sh), S(cx + 40), S(top + sh + 8)), radius=S(4), fill=(180, 174, 206, 255))
    d.rounded_rectangle((S(x1), S(top), S(x2), S(top + sh + 2)), radius=S(16), fill=(30, 22, 66, 255))
    scr = (x1 + 11, top + 11, x2 - 11, top + sh - 8)
    DW = 440
    DH = int(DW * (scr[3] - scr[1]) / (scr[2] - scr[0]))
    bgmain = bg
    bg = Image.new('RGBA', (S(DW), S(DH)), (255, 255, 255, 255))  # UI is drawn at a fixed design size, then scaled onto the screen
    d = ImageDraw.Draw(bg, 'RGBA')
    sx1, sy1, sx2, sy2 = 0, 0, DW, DH
    sw_ = sx2 - sx1
    # nav bar with logo on every laptop
    d.rectangle((S(sx1), S(sy1), S(sx2), S(sy1 + 36)), fill=mix(a1, (255, 255, 255), 0.9) + (255,))
    bg.alpha_composite(_logo_badge(S(26)), (S(sx1 + 10), S(sy1 + 5)))
    d = ImageDraw.Draw(bg, 'RGBA')
    txt(d, sx1 + 42, sy1 + 18, 'Xexnaro', font('bold', 15), th['ink'] if not dark else (30, 12, 80), 'lm')
    for k in range(3):
        d.rounded_rectangle((S(sx2 - 86 + k * 26), S(sy1 + 15), S(sx2 - 70 + k * 26), S(sy1 + 21)), radius=S(3), fill=(190, 182, 222, 255))
    bx1, by1, bx2, by2 = sx1 + 14, sy1 + 48, sx2 - 14, sy2 - 12
    bw, bh = bx2 - bx1, by2 - by1

    def bar(x, y, ww, hh, c, r=4):
        d.rounded_rectangle((S(x), S(y), S(x + ww), S(y + hh)), radius=S(r), fill=c)

    soft = mix(a1, (255, 255, 255), 0.85) + (255,)
    gray = (222, 218, 240, 255)
    if kind == 'website':
        bar(bx1, by1 + 4, bw * 0.5, 13, th['ink'] + (255,)); bar(bx1, by1 + 24, bw * 0.38, 13, a1 + (255,))
        bar(bx1, by1 + 50, bw * 0.48, 6, gray); bar(bx1, by1 + 62, bw * 0.4, 6, gray)
        bar(bx1, by1 + 82, 70, 22, a1 + (255,), 11)
        d.rounded_rectangle((S(bx1 + bw * 0.56), S(by1 + 2), S(bx2), S(by1 + 108)), radius=S(10), fill=mix(a2, (255, 255, 255), 0.5) + (255,))
        icon(d, 'globe', bx1 + bw * 0.78, by1 + 55, 24, (255, 255, 255), 3)
        for k in range(3):
            bar(bx1 + k * (bw / 3), by1 + 124, bw / 3 - 8, bh - 124, soft, 8)
    elif kind == 'chart':
        for k in range(4):
            bar(bx1 + k * (bw / 4), by1, bw / 4 - 8, 34, soft, 8)
            bar(bx1 + k * (bw / 4) + 8, by1 + 8, 28, 6, a1 + (255,)); bar(bx1 + k * (bw / 4) + 8, by1 + 20, 44, 8, th['ink'] + (255,))
        base = by2 - 4
        hs = [0.25, 0.4, 0.34, 0.55, 0.7, 0.62, 0.9]
        area = bh - 56
        for k, v in enumerate(hs):
            bar(bx1 + 6 + k * (bw / 7), base - v * area, bw / 7 - 14, v * area, mix(a1, a2, k / 6) + (255,), 5)
        pts = [(S(bx1 + 6 + k * (bw / 7) + (bw / 7 - 14) / 2), S(base - v * area - 12)) for k, v in enumerate(hs)]
        d.line(pts, fill=(245, 158, 11, 255) if not dark else (255, 200, 90, 255), width=S(4), joint='curve')
        for q in pts:
            d.ellipse((q[0] - S(5), q[1] - S(5), q[0] + S(5), q[1] + S(5)), fill=(255, 255, 255, 255), outline=(245, 158, 11, 255), width=S(3))
    elif kind == 'social':
        cols = 3
        tw_, th_ = (bw - 20) / cols, (bh - 12) / 2
        names = ['play', 'chat', 'star', 'people', 'play', 'calendar']
        for k in range(6):
            xx, yy = bx1 + (k % cols) * (tw_ + 10), by1 + (k // cols) * (th_ + 12)
            c = mix(a1, a2, k / 5)
            d.rounded_rectangle((S(xx), S(yy), S(xx + tw_), S(yy + th_)), radius=S(10), fill=mix(c, (255, 255, 255), 0.35) + (255,))
            icon(d, names[k], xx + tw_ / 2, yy + th_ / 2 - 4, 17, (255, 255, 255), 3)
            bar(xx + 8, yy + th_ - 14, tw_ * 0.5, 5, (255, 255, 255, 200), 3)
    elif kind == 'search':
        d.rounded_rectangle((S(bx1), S(by1), S(bx2), S(by1 + 34)), radius=S(17), outline=a1 + (255,), width=S(3), fill=(255, 255, 255, 255))
        icon(d, 'search', bx1 + 22, by1 + 17, 11, a1, 3)
        bar(bx1 + 42, by1 + 14, bw * 0.4, 7, gray)
        for k in range(3):
            yy = by1 + 50 + k * 56
            if k == 0:
                d.rounded_rectangle((S(bx1), S(yy - 6), S(bx2), S(yy + 46)), radius=S(10), fill=soft)
                d.rounded_rectangle((S(bx2 - 62), S(yy + 2), S(bx2 - 10), S(yy + 20)), radius=S(9), fill=a2 + (255,))
                txt(d, bx2 - 36, yy + 11, '#1', font('bold', 12), (255, 255, 255), 'mm')
            bar(bx1 + 10, yy, bw * 0.34, 8, a1 + (255,)); bar(bx1 + 10, yy + 16, bw * 0.7, 6, gray); bar(bx1 + 10, yy + 28, bw * 0.55, 6, gray)
    elif kind == 'brand':
        bg.alpha_composite(_logo_badge(S(88)), (S(bx1 + 6), S(by1 + 4)))
        d = ImageDraw.Draw(bg, 'RGBA')
        for k, c in enumerate((a1, a2, mix(a1, (0, 0, 0), 0.35), mix(a2, (255, 255, 255), 0.55))):
            d.ellipse((S(bx1 + 120 + k * 46), S(by1 + 8), S(bx1 + 160 + k * 46), S(by1 + 48)), fill=c + (255,))
        txt(d, bx1 + 122, by1 + 68, 'Aa', font('bold', 36), th['ink'] if not dark else (30, 12, 80))
        bar(bx1 + 200, by1 + 76, 90, 7, gray); bar(bx1 + 200, by1 + 90, 64, 7, gray)
        for k in range(3):
            bar(bx1 + k * (bw / 3), by1 + 124, bw / 3 - 8, bh - 124, mix(a1, a2, k / 2.5) + (255,) if k == 1 else soft, 8)
    elif kind == 'strategy':
        steps = [('target', 'Goals'), ('people', 'Audience'), ('megaphone', 'Channels'), ('chart', 'Results')]
        gw = (bw - 3 * 14) / 4
        for k, (ic, lb) in enumerate(steps):
            xx = bx1 + k * (gw + 14)
            d.rounded_rectangle((S(xx), S(by1 + 18), S(xx + gw), S(by1 + 18 + gw + 20)), radius=S(12), fill=soft)
            d.ellipse((S(xx + gw / 2 - 20), S(by1 + 28), S(xx + gw / 2 + 20), S(by1 + 68)), fill=a1 + (255,))
            icon(d, ic, xx + gw / 2, by1 + 48, 12, (255, 255, 255), 2.6)
            txt(d, xx + gw / 2, by1 + 90, lb, font('medium', 11), th['ink'] if not dark else (30, 12, 80), 'mm')
            if k < 3:
                d.polygon([(S(xx + gw + 2), S(by1 + 44)), (S(xx + gw + 12), S(by1 + 49)), (S(xx + gw + 2), S(by1 + 54))], fill=a2 + (255,))
        pr = bh - (gw + 58)
        for k in range(3):
            bar(bx1, by1 + gw + 50 + k * 20, bw * (0.9 - k * 0.2), 9, (a1 if k == 0 else a2) + (255,) if k < 2 else gray, 5)
    elif kind == 'shop':
        for k in range(3):
            xx = bx1 + k * (bw / 3)
            ww = bw / 3 - 10
            d.rounded_rectangle((S(xx), S(by1), S(xx + ww), S(by1 + bh * 0.58)), radius=S(10), fill=mix(mix(a1, a2, k / 2), (255, 255, 255), 0.6) + (255,))
            icon(d, ['phone', 'palette', 'star'][k], xx + ww / 2, by1 + bh * 0.29, 18, mix(a1, (0, 0, 0), 0.1), 3)
            bar(xx + 4, by1 + bh * 0.64, ww * 0.7, 7, th['ink'] + (255,) if not dark else (30, 12, 80, 255)); bar(xx + 4, by1 + bh * 0.64 + 14, ww * 0.4, 6, gray)
        d.rounded_rectangle((S(bx2 - 70), S(by2 - 26), S(bx2), S(by2)), radius=S(13), fill=a1 + (255,))
        icon(d, 'cart', bx2 - 35, by2 - 13, 9, (255, 255, 255), 2.4)
    else:  # mail / contact
        d.rounded_rectangle((S(bx1), S(by1 + 6), S(bx1 + bw * 0.62), S(by1 + 58)), radius=S(14), fill=soft)
        bar(bx1 + 14, by1 + 22, bw * 0.4, 7, gray); bar(bx1 + 14, by1 + 36, bw * 0.3, 7, gray)
        d.rounded_rectangle((S(bx1 + bw * 0.3), S(by1 + 72), S(bx2), S(by1 + 124)), radius=S(14), fill=a1 + (255,))
        bar(bx1 + bw * 0.3 + 14, by1 + 88, bw * 0.4, 7, (255, 255, 255, 230)); bar(bx1 + bw * 0.3 + 14, by1 + 102, bw * 0.28, 7, (255, 255, 255, 180))
        d.ellipse((S(bx1 + bw * 0.5 - 28), S(by1 + 138), S(bx1 + bw * 0.5 + 28), S(by1 + 194)), fill=a2 + (255,))
        icon(d, 'mail', bx1 + bw * 0.5, by1 + 166, 15, (255, 255, 255), 3)
    ui = bg.resize((S(scr[2] - scr[0]), S(scr[3] - scr[1])), Image.LANCZOS)
    um = Image.new('L', ui.size, 0)
    ImageDraw.Draw(um).rounded_rectangle((0, 0, ui.width - 1, ui.height - 1), radius=S(8), fill=255)
    bgmain.paste(ui, (S(scr[0]), S(scr[1])), um)
    return bgmain.convert('RGBA')


def photo_shape(img, th, entry):
    shape = th['photo']
    boxes = {'fade': (590, 0, 1080, 470), 'round': (655, 60, 1035, 450), 'circle': (665, 50, 1035, 420), 'arch': (680, 30, 1030, 452),
             'hex': (660, 40, 1030, 452), 'diag': (640, 40, 1060, 450)}
    x1, y1, x2, y2 = boxes[shape]
    w, h = x2 - x1, y2 - y1
    ph = hero_image(w, h, th, entry)
    pw, phh = ph.size
    mask = Image.new('L', ph.size, 0)
    md = ImageDraw.Draw(mask)
    if shape == 'fade':
        mask = Image.new('L', ph.size, 255)
        left = Image.linear_gradient('L').rotate(90).resize((int(pw * 0.45), phh))
        mask.paste(left, (0, 0))
        bottom = Image.linear_gradient('L').rotate(180).resize((pw, int(phh * 0.22)))
        bm = Image.new('L', ph.size, 255)
        bm.paste(bottom, (0, phh - bottom.height))
        mask = ImageChops.multiply(mask, bm)
    elif shape == 'round':
        md.rounded_rectangle((0, 0, pw - 1, phh - 1), radius=S(46), fill=255)
    elif shape == 'circle':
        md.ellipse((0, 0, pw - 1, phh - 1), fill=255)
    elif shape == 'arch':
        md.ellipse((0, 0, pw - 1, pw - 1), fill=255)
        md.rounded_rectangle((0, pw // 2, pw - 1, phh - 1), radius=S(30), fill=255)
    elif shape == 'hex':
        md.polygon([(pw * 0.5, 0), (pw, phh * 0.25), (pw, phh * 0.75), (pw * 0.5, phh), (0, phh * 0.75), (0, phh * 0.25)], fill=255)
    elif shape == 'diag':
        md.polygon([(pw * 0.2, 0), (pw, 0), (pw * 0.8, phh), (0, phh)], fill=255)
    if shape != 'fade':
        # soft shadow + coloured frame so the photo sits on the page
        sh = layer(img)
        shm = Image.new('L', ph.size, 0)
        shm.paste(mask, (0, 0))
        sh.paste(Image.new('RGBA', ph.size, (30, 12, 90, 80)), (S(x1) + S(6), S(y1) + S(14)), shm)
        img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(S(14))))
        frame = layer(img)
        big = mask.filter(ImageFilter.MaxFilter(S(5) | 1))
        frame.paste(Image.new('RGBA', ph.size, th['accent2'] + (255,)), (S(x1), S(y1)), big)
        img.alpha_composite(frame)
    ph.putalpha(mask)
    img.alpha_composite(ph, (S(x1), S(y1)))


def draw_logo(img, th):
    if not os.path.exists(LOGO_PATH):
        raise FileNotFoundError('Xexnaro logo missing: ' + LOGO_PATH)
    size = 92
    x, y = 48, 34
    lg = ImageOps.fit(Image.open(LOGO_PATH).convert('RGB'), (S(size), S(size)), Image.LANCZOS).convert('RGBA')
    m = Image.new('L', lg.size, 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, lg.width - 1, lg.height - 1), radius=S(24), fill=255)
    shadow(img, (x, y, x + size, y + size), 24, (0, 8), 10, (30, 10, 100, 70))
    d = ImageDraw.Draw(img, 'RGBA')
    d.rounded_rectangle((S(x - 4), S(y - 4), S(x + size + 4), S(y + size + 4)), radius=S(28), fill=(255, 255, 255, 255))
    img.paste(lg, (S(x), S(y)), m)
    d = ImageDraw.Draw(img, 'RGBA')
    ink = th['ink']
    txt(d, x + size + 20, y - 8, 'Xexnaro', font('bold', 64), ink)
    spaced(d, x + size + 24, y + 68, 'DIGITAL GROWTH PARTNER', font('medium', 15), th['muted'], 3.4)


def draw_script(img, th, words):
    f = font('medium', 50)
    lay = Image.new('RGBA', (S(330), S(190)), (0, 0, 0, 0))
    ld = ImageDraw.Draw(lay)
    col = th['script']
    txt(ld, 24, 2, words[0], f, col)
    txt(ld, 70, 52, words[1], f, col)
    pts = []
    for k in range(24):
        t = k / 23
        x = 40 + t * 250
        y = 150 - 22 * math.sin(t * math.pi * 1.1) - 16 * t
        pts.append((S(x), S(y)))
    ld.line(pts, fill=col, width=S(4), joint='curve')
    ex, ey = pts[-1]
    ld.polygon([(ex + S(12), ey - S(4)), (ex - S(12), ey - S(15)), (ex - S(6), ey + S(10))], fill=col)
    lay = lay.transform(lay.size, Image.AFFINE, (1, 0.26, -S(14), 0, 1, 0), resample=Image.BICUBIC)
    lay = lay.rotate(6, resample=Image.BICUBIC)
    img.alpha_composite(lay, (S(745), S(462)))


def draw_tag(img, th, text):
    d = ImageDraw.Draw(img, 'RGBA')
    f = font('bold', 25)
    x, y, h = 52, 218, 62
    w = int(tw(text, f)) + 108
    a, b = th['accent'], th['accent2']
    pill = hgrad((S(w), S(h)), a, b)
    m = Image.new('L', pill.size, 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, pill.width - 1, pill.height - 1), radius=S(h / 2), fill=255)
    shadow(img, (x, y, x + w, y + h), h / 2, (0, 8), 10, a + (70,))
    img.paste(pill, (S(x), S(y)), m)
    d = ImageDraw.Draw(img, 'RGBA')
    d.ellipse((S(x), S(y), S(x + h), S(y + h)), fill=mix(a, (0, 0, 0), 0.25) + (255,))
    icon(d, 'bulb', x + h / 2, y + h / 2, 17, (255, 255, 255), 2.6)
    txt(d, x + h + 18, y + h / 2 + 1, text, f, (255, 255, 255), 'lm')
    return y + h


def draw_card(img, th, x, y, w, h, pt):
    style, acc, dark = th['card'], th['accent'], th['dark']
    d = ImageDraw.Draw(img, 'RGBA')
    title_c, desc_c = th['ink'], th['muted']
    ic_bg, ic_col = mix(acc, (255, 255, 255), 0.84) + (255,), acc
    if th['dark'] and style == 'white':
        title_c, desc_c = (20, 12, 70), (84, 76, 124)
        ic_col = (98, 40, 220)
    shadow(img, (x, y, x + w, y + h), 28, (0, 10), 14, (20, 8, 80, 60 if dark else 40))
    d = ImageDraw.Draw(img, 'RGBA')
    if style == 'glass':
        gl = layer(img)
        ImageDraw.Draw(gl).rounded_rectangle((S(x), S(y), S(x + w), S(y + h)), radius=S(28), fill=(255, 255, 255, 34), outline=(255, 255, 255, 90), width=S(2))
        img.alpha_composite(gl)
        d = ImageDraw.Draw(img, 'RGBA')
        title_c, desc_c, ic_bg, ic_col = (255, 255, 255), (214, 206, 246), mix(th['bg'][1], (255, 255, 255), 0.22) + (255,), (255, 255, 255)
    elif style == 'outline':
        d.rounded_rectangle((S(x), S(y), S(x + w), S(y + h)), radius=S(28), fill=mix(acc, (255, 255, 255), 0.96) + (255,), outline=acc + (255,), width=S(3))
    else:
        d.rounded_rectangle((S(x), S(y), S(x + w), S(y + h)), radius=S(28), fill=(255, 255, 255, 255), outline=(228, 220, 250, 255), width=S(2))
        if style == 'topbar':
            bar = Image.new('RGBA', (S(w), S(h)), (0, 0, 0, 0))
            bd = ImageDraw.Draw(bar)
            bd.rectangle((0, 0, S(w), S(9)), fill=acc + (255,))
            cm = Image.new('L', bar.size, 0)
            ImageDraw.Draw(cm).rounded_rectangle((0, 0, bar.width - 1, bar.height - 1), radius=S(28), fill=255)
            bar.putalpha(ImageChops.multiply(bar.getchannel('A'), cm))
            img.alpha_composite(bar, (S(x), S(y)))
        elif style == 'leftbar':
            bar = Image.new('RGBA', (S(w), S(h)), (0, 0, 0, 0))
            ImageDraw.Draw(bar).rectangle((0, 0, S(9), S(h)), fill=th['accent2'] + (255,))
            cm = Image.new('L', bar.size, 0)
            ImageDraw.Draw(cm).rounded_rectangle((0, 0, bar.width - 1, bar.height - 1), radius=S(28), fill=255)
            bar.putalpha(ImageChops.multiply(bar.getchannel('A'), cm))
            img.alpha_composite(bar, (S(x), S(y)))
    d = ImageDraw.Draw(img, 'RGBA')
    cx, cy = x + 26 + 32, y + 26 + 32
    d.ellipse((S(cx - 32), S(cy - 32), S(cx + 32), S(cy + 32)), fill=ic_bg)
    icon(d, pt['icon'], cx, cy, 19, ic_col, 3.0)
    tf = font('bold', 22)
    yy = y + 112
    for ln in wrap(pt['title'], tf, w - 46)[:2]:
        txt(d, x + 24, yy, ln, tf, title_c)
        yy += 29
    yy += 8
    df = font('regular', 17)
    for ln in wrap(pt['desc'], df, w - 46)[:4]:
        txt(d, x + 24, yy, ln, df, desc_c)
        yy += 24


def draw_footer(img, th):
    top = 900
    h = H - top
    foot0, foot1 = th['foot']
    wavef = th['wave']

    def edge(kind, shift=0.0, amp=1.0):
        pts = []
        for i in range(0, 109):
            x = i * 10
            t = x / W
            if kind == 'wave':
                y = 55 + 24 * amp * math.sin(2 * math.pi * t * 1.25 + 0.9 + shift) - 4
            elif kind == 'double':
                y = 52 + 20 * amp * math.sin(2 * math.pi * t * 1.0 + 0.4 + shift)
            elif kind == 'slant':
                y = 60 - 36 * t + 7 * amp * math.sin(2 * math.pi * t * 2 + shift)
            else:  # arc
                y = 62 - 38 * math.sin(math.pi * t) + 4 * amp * math.sin(2 * math.pi * t * 3 + shift)
            pts.append((S(x), S(y)))
        return pts

    def band(edge_pts, c0, c1, alpha=255):
        g = vgrad((S(W), S(h)), c0, c1)
        m = Image.new('L', g.size, 0)
        ImageDraw.Draw(m).polygon(edge_pts + [(S(W), S(h)), (0, S(h))], fill=alpha)
        g.putalpha(m)
        img.alpha_composite(g, (0, S(top)))

    if wavef == 'double':
        band([(x, y - S(18)) for x, y in edge('double', 1.6, 0.9)], th['accent2'], mix(th['accent2'], foot1, 0.5), 150)
    elif wavef == 'wave':
        band([(x, y - S(14)) for x, y in edge('wave', 2.2, 0.7)], mix(foot1, (255, 255, 255), 0.5), foot1, 110)
    band(edge(wavef), foot1 if wavef in ('wave', 'arc') else mix(foot1, foot0, 0.3), foot0)
    d = ImageDraw.Draw(img, 'RGBA')
    # website pill
    px, py, pw_, ph_ = 64, 984, 350, 58
    d.rounded_rectangle((S(px), S(py), S(px + pw_), S(py + ph_)), radius=S(ph_ / 2), outline=(255, 255, 255, 255), width=S(3))
    icon(d, 'globe', px + 40, py + ph_ / 2, 15, (255, 255, 255), 2.6)
    txt(d, px + 74, py + ph_ / 2 + 1, 'www.xexnaro.in', font('bold', 27), (255, 255, 255), 'lm')
    # tagline
    tf = font('bold', 26)
    tag = 'Build Online. Grow Beyond.'
    tx = 1032
    txt(d, tx, py + ph_ / 2 + 1, tag, tf, (255, 255, 255), 'rm')
    lx = tx - tw(tag, tf) - 24
    d.line((S(lx), S(py + 4), S(lx), S(py + ph_ - 4)), fill=(255, 255, 255, 200), width=S(2))


def build_template(idx, entry):
    th = THEMES[idx - 1]
    img = vgrad((S(W), S(H)), *th['bg'])
    deco(img, th)
    photo_shape(img, th, entry)
    draw_logo(img, th)
    draw_script(img, th, entry['script'])
    y = draw_tag(img, th, entry['tag'])
    d = ImageDraw.Draw(img, 'RGBA')
    # headline (two-tone)
    lines = entry['headline'][:2]
    yy = y + 30
    for i, t in enumerate(lines):
        f, size = fit(t, {'fade': 650, 'round': 595, 'circle': 600, 'arch': 615, 'hex': 595, 'diag': 580}[th['photo']], 68, 40)
        txt(d, 52, yy, t, f, th['ink'] if i == 0 else th['hl2'])
        yy += int(size * 1.13)
    # intro
    sf = font('regular', 23)
    yy += 8
    for ln in wrap(entry['sub'], sf, 610)[:3]:
        txt(d, 52, yy, ln, sf, th['muted'])
        yy += 34
    yy += 6
    d.rounded_rectangle((S(52), S(yy), S(52 + 150), S(yy + 7)), radius=S(4), fill=th['accent'] + (255,))
    # cards
    cw, gap, cy, chh = 232, 20, 630, 262
    x0 = (W - (4 * cw + 3 * gap)) // 2
    for i, pt in enumerate(entry['points'][:4]):
        draw_card(img, th, x0 + i * (cw + gap), cy, cw, chh, pt)
    draw_footer(img, th)
    return img.resize((W, H), Image.LANCZOS).convert('RGB')


# --------------------------------------------------------------------------
# Content + CLI
# --------------------------------------------------------------------------
def load_kb():
    with open(KB_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)


def check(entry):
    text = json.dumps(entry, ensure_ascii=False)
    blocked = [r'[\u20b9$\u20ac\u00a3]', r'\b(?:rs|inr)\.?\s*\d', r'\b(?:price|pricing|discount|cheap|cost|offer price)\b',
               r'\b(?:call|whatsapp|phone number)\b', r'\+?\d[\d\s-]{8,}\d']
    for pat in blocked:
        if re.search(pat, text, re.I):
            raise ValueError('Blocked promotional/contact wording: ' + pat)
    if len(entry['points']) < 4:
        raise ValueError('Each post needs 4 points')


def pick(day, posts, template=None):
    return posts[day.toordinal() % len(posts)]


def build(day, template=None, kb=None, post_index=None):
    kb = kb or load_kb()
    posts = kb['posts']
    entry = posts[post_index] if post_index is not None else pick(day, posts)
    check(entry)
    idx = int(template) if template else ((day.toordinal() - 1) % len(THEMES)) + 1
    if idx < 1 or idx > len(THEMES):
        raise ValueError('template must be 1-%d' % len(THEMES))
    return build_template(idx, entry), entry, idx


def slug(s):
    return re.sub(r'[^a-z0-9]+', '_', s.lower()).strip('_')


def generate(day, template=None, out_dir=OUTPUT_DIR):
    os.makedirs(out_dir, exist_ok=True)
    img, entry, idx = build(day, template)
    base = os.path.join(out_dir, 'xexnaro_daily_template_%02d' % idx)
    img.save(base + '.png')
    img.save(base + '.jpg', 'JPEG', quality=95, optimize=True)
    return base + '.png', entry, idx


def generate_ten(out_dir=TEMPLATE_DIR):
    """Day 1..10: template N is paired with post N (all different)."""
    os.makedirs(out_dir, exist_ok=True)
    kb = load_kb()
    paths = []
    for n in range(1, 11):
        img, entry, _ = build(date.today(), n, kb, post_index=(n - 1) % len(kb['posts']))
        p = os.path.join(out_dir, 'day_%02d_template_%02d_%s.png' % (n, n, slug(entry['tag'])))
        img.save(p)
        paths.append(p)
    return paths


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--date')
    ap.add_argument('--days', type=int, default=1)
    ap.add_argument('--template', type=int, choices=range(1, 11))
    ap.add_argument('--all-templates', action='store_true', help='write the 10-day series (10 templates x 10 posts)')
    ap.add_argument('--out', default=OUTPUT_DIR)
    a = ap.parse_args()
    if a.all_templates:
        for p in generate_ten():
            print(p)
        return
    start = datetime.strptime(a.date, '%Y-%m-%d').date() if a.date else date.today()
    for i in range(a.days):
        day = start + timedelta(days=i)
        p, e, t = generate(day, a.template, a.out)
        print('Template %02d | %s | %s' % (t, e['tag'], p))


if __name__ == '__main__':
    main()
